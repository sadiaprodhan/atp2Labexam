﻿using MvcAppLabExam.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcAppLabExam.Controllers
{
    public class RegistrationController : Controller
    {
        //
        // GET: /Registration/
        UserRepo u = new UserRepo();

        [HttpGet]
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Index(string email, string password, string username)
        {
            int count = u.Insert(email, password, username);
            if (count >= 1)
            { return RedirectToAction("Index", "Diary"); }
            else
            { return Content("Registration Unsuccessful"); }
        }

    }
}

