﻿using MvcAppLabExam.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcAppLabExam.Controllers
{
    public class UserController : Controller
    {
        //
        // GET: /Home/
        UserRepo urepo = new UserRepo();
        [HttpGet]
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Index(int id, string password)
        {
            User user = urepo.Get(id, password);
            if (user.Id != null)
            {
                Session["id"] = user.Id;
                Session["password"] = user.Password;
                Session["UserName"] = user.UserName;
                Session["Email"] = user.Email;
                return RedirectToAction("Index", "Diary");
            }
            else
            { return Content("Wrong UserId and Password"); }
        }


    }
}

