﻿using MvcAppLabExam.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Helpers;
using System.Web.Mvc;

namespace MvcAppLabExam.Controllers
{
    public class DiaryController : Controller
    { WebImage photo=null;
        string newFileName;
        string imagePath;
        //
        // GET: /Diary/
        DiaryRepo dr = new DiaryRepo();

        public ActionResult Index()
        {
            return View(dr.GetAll());
        }

        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Create(string date, string image, string Thoughts, string Importance)
        {    photo = WebImage.GetImageFromRequest();
        if(photo != null){
            newFileName = Guid.NewGuid().ToString() + "_" +
                Path.GetFileName(photo.FileName);
            imagePath = @"images\" + newFileName;

            photo.Save(@"~\" + imagePath);

            int count= dr.Insert
        
        
        
        }
    }
}
