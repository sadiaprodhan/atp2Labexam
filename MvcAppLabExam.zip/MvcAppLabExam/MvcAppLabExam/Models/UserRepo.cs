﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace MvcAppLabExam.Models
{
    public class UserRepo
    {
          DataAccess data;
        public UserRepo()
        {
            data = new DataAccess();
        }

        public User Get(int id,string password)
        {
            string sql = "SELECT * FROM [User] where Id="+id+" and Password='"+password+"'";
            SqlDataReader reader = data.GetData(sql);
            User u = new User();
            if (reader.Read())
            {
               


                u.Id = Convert.ToInt32(reader["Id"]);
                u.UserName = reader["UserName"].ToString();
                u.Email = reader["Email"].ToString();
                u.Password = reader["Password"].ToString();
               
            }
            return u;
        }
        public int Insert(string email,string password, string username)
        {
            string sql = "INSERT INTO [User] (Password,UserName,Email) VALUES('" + password + "','" + username + "','" + email + "')";
            return data.ExecuteQuery(sql);
        }
    }
}