﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcAppLabExam.Models
{
    public class Diary
    { public int Diaryid {get; set;}
        public string Date {get; set;}
        public string Thoughts { get; set; }
        public string Image { get; set; }
        public string Importance { get; set; }

    }
}