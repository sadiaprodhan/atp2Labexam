﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace MvcAppLabExam.Models
{
    public class DiaryRepo
    {


         DataAccess data;
        public DiaryRepo ()
        {
            data = new DataAccess();
        }

        public List<Diary> GetAll()
        {
            string sql = "SELECT * FROM PersonalDiary";
            SqlDataReader reader = data.GetData(sql);
            List<Diary> diaryList = new List<Diary>();
            while (reader.Read())
            {
                Diary d = new Diary();
                d.Diaryid = Convert.ToInt32(reader["diaryid"]);
                d.Thoughts = reader["Thoughts"].ToString();
                d.Date = reader["Date"].ToString();
                d.Image = reader["Image"].ToString();
                d.Importance = reader["Importance"].ToString();
                diaryList.Add(d);
            }
            return diaryList;
        }
        public int Insert(string date, string image, string Thoughts, string Importance)
        {
            string sql = "INSERT INTO [PersonalDiary] (Date,Thoughts,Image,Importance) VALUES('" + date + "','" + Thoughts + "','" + image + "','" + Importance + "')";
            return data.ExecuteQuery(sql);
        
        }
    }
}