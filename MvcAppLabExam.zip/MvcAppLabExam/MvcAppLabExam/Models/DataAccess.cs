﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
 

using System.Data.SqlClient;
using System.Configuration;
namespace MvcAppLabExam.Models
{
     public class DataAccess:IDisposable
    {
        SqlConnection connection;
        SqlCommand command;

        public DataAccess()
        {
            //this.connection = new SqlConnection(@"data source=.\sqlexpress;initial catalog=PersonDb;integrated security=true;");
            //this.connection = new SqlConnection(@"server=.\sqlexpress;database=PersonDb;integrated security=true;");
            this.connection = new SqlConnection(ConfigurationManager.ConnectionStrings["PDB"].ConnectionString);
            this.connection.Open();
        }


        public SqlDataReader GetData(string sql)
        {
            this.command = new SqlCommand(sql,connection);
            return this.command.ExecuteReader();
        }
        
        public int ExecuteQuery(string sql)
        {
            this.command = new SqlCommand(sql, connection);
            return this.command.ExecuteNonQuery();
        }

        public void Dispose()
        {
            this.connection.Close();
        }
    }
}
